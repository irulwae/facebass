# Facebash v1.0
## Author: github.com/thelinuxchoice
## IG: @thelinuxchoice
Facebook Brute Forcer in shellscript using TOR

### WARNING:
```
Facebook blocks account for 1 hour after 20 wrong passwords, so this script can perform only 20 pass/h.
```

![facebash](https://user-images.githubusercontent.com/34893261/37884926-d3f1df94-3088-11e8-98c3-1513f22e627c.png)

### Features

- Save/Resume sessions
- Anonymous attack through TOR
- Default Password List (+39k)


### Usage:

```
git clone https://github.com/thelinuxchoice/facebash
cd instashell
chmod +x facebash.sh
service tor start
sudo ./facebash.sh
```

### Install requirements (Curl, Tor):

```
chmod +x install.sh
sudo ./install.sh
```
